(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const coarse = window.matchMedia('(pointer: coarse)').matches;

  document.body.classList.toggle('cursor-ready', !coarse);

  /* ---------------------------------------------------------
     PAGE PROGRESS
  --------------------------------------------------------- */
  const progress = $('#pageProgress span');
  const updateProgress = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const value = max > 0 ? (window.scrollY / max) * 100 : 0;
    if (progress) progress.style.width = `${value}%`;
  };

  /* ---------------------------------------------------------
     PREMIUM CURSOR + HERO MAGNIFIER REVEAL
  --------------------------------------------------------- */
  const lens = $('#cursorLens');
  const center = $('#cursorCenter');
  const heroReveal = $('#heroReveal');
  const orbitA = $('.cursor-orbit-a');
  const orbitB = $('.cursor-orbit-b');

  const pointer = { x: innerWidth / 2, y: innerHeight / 2 };
  const smooth = { x: pointer.x, y: pointer.y };
  const slow = { x: pointer.x, y: pointer.y };
  let pointerActive = !coarse;

  const movePointer = (e) => {
    if (!pointerActive) return;
    pointer.x = e.clientX;
    pointer.y = e.clientY;
  };
  window.addEventListener('pointermove', movePointer, { passive: true });

  const renderCursor = () => {
    if (!pointerActive) return;
    smooth.x += (pointer.x - smooth.x) * .2;
    smooth.y += (pointer.y - smooth.y) * .2;
    slow.x += (pointer.x - slow.x) * .08;
    slow.y += (pointer.y - slow.y) * .08;

    const setPos = (el, x, y) => {
      if (el) el.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, -50%)`;
    };
    setPos(lens, smooth.x, smooth.y);
    setPos(orbitA, slow.x, slow.y);
    setPos(orbitB, slow.x, slow.y);

    if (heroReveal) {
      const radius = Math.min(320, Math.max(180, innerWidth * .22));
      const mask = `radial-gradient(circle ${radius}px at ${slow.x}px ${slow.y}px, #000 0%, #000 40%, rgba(0,0,0,.8) 60%, transparent 100%)`;
      heroReveal.style.webkitMaskImage = mask;
      heroReveal.style.maskImage = mask;
    }
    requestAnimationFrame(renderCursor);
  };
  if (!coarse && !reduceMotion) requestAnimationFrame(renderCursor);

  const cursorTargets = () => $$('.magnetic-target, a, button, input, textarea, select').forEach((el) => {
    el.addEventListener('mouseenter', () => {
      if (!lens || coarse) return;
      lens.classList.add('is-hover');
      const type = el.dataset.cursor;
      lens.classList.toggle('is-ai', type === 'ai');
      lens.classList.toggle('is-launch', type === 'launch');
      lens.classList.toggle('is-brand', type === 'brand');
      if (type === 'ai') center.textContent = '🤖';
      else center.textContent = '🔍';
    });
    el.addEventListener('mouseleave', () => {
      if (!lens || coarse) return;
      lens.classList.remove('is-hover', 'is-ai', 'is-launch', 'is-brand');
      center.textContent = '⌕';
    });
  });
  if (!coarse) cursorTargets();

  /* ---------------------------------------------------------
     NAVIGATION + MOBILE MENU
  --------------------------------------------------------- */
  const navbar = $('#navbar');
  const menuToggle = $('#menuToggle');
  const mobileMenu = $('#mobileMenu');

  const updateNav = () => {
    navbar?.classList.toggle('scrolled', window.scrollY > 46);
    updateProgress();
  };
  window.addEventListener('scroll', updateNav, { passive: true });
  updateNav();

  menuToggle?.addEventListener('click', () => {
    const open = mobileMenu.classList.toggle('open');
    menuToggle.classList.toggle('open', open);
    menuToggle.setAttribute('aria-expanded', String(open));
  });

  $$('.mobile-link').forEach((link) => link.addEventListener('click', () => {
    mobileMenu?.classList.remove('open');
    menuToggle?.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
  }));

  /* Active nav based on section visibility */
  const navLinks = $$('.nav-link');
  const navSections = $$('main[id], section[id]');
  if ('IntersectionObserver' in window) {
    const navObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        navLinks.forEach((link) => link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`));
      });
    }, { rootMargin: '-30% 0px -55% 0px', threshold: 0 });
    navSections.forEach((section) => navObserver.observe(section));
  }

  /* ---------------------------------------------------------
     SCROLL REVEALS
  --------------------------------------------------------- */
  const revealItems = $$('.reveal-on-scroll');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: .12 });
    revealItems.forEach((el) => revealObserver.observe(el));
  } else {
    revealItems.forEach((el) => el.classList.add('is-visible'));
  }

  /* ---------------------------------------------------------
     SUBTLE CARD MAGNETISM
  --------------------------------------------------------- */
  $$('.magnetic-card').forEach((card) => {
    if (coarse || reduceMotion) return;
    card.addEventListener('pointermove', (e) => {
      const r = card.getBoundingClientRect();
      const dx = (e.clientX - r.left) / r.width - .5;
      const dy = (e.clientY - r.top) / r.height - .5;
      card.style.transform = `perspective(900px) rotateX(${(-dy * 2.6).toFixed(2)}deg) rotateY(${(dx * 3.2).toFixed(2)}deg) translateY(-7px)`;
    });
    card.addEventListener('pointerleave', () => { card.style.transform = ''; });
  });

  /* ---------------------------------------------------------
     TRUST TOOL TABS
  --------------------------------------------------------- */
  $$('.tool-tab').forEach((tab) => tab.addEventListener('click', () => {
    const target = tab.dataset.target;
    $$('.tool-tab').forEach((x) => x.classList.toggle('active', x === tab));
    $$('.tool-panel').forEach((panel) => panel.classList.toggle('active', panel.id === target));
    $('#trustResults')?.classList.remove('active');
    $('#trustLoading')?.classList.remove('active');
  }));

  const trustLoading = $('#trustLoading');
  const trustResults = $('#trustResults');
  const resultCircle = $('#resultCircle');
  const resultScore = $('#resultScore');
  const resultTitle = $('#resultTitle');
  const resultDesc = $('#resultDesc');
  const resultSignals = $('#resultSignals');
  const circumference = 2 * Math.PI * 50;

  const trustData = {
    privacy: {
      score: 78,
      title: 'Privacy policy assessment',
      desc: 'Several safeguards are present, but user control and third-party sharing deserve a closer read.',
      signals: [
        ['warn', 'Third-party sharing', 'Partner and analytics sharing language should be checked for scope.'],
        ['good', 'Retention language', 'A defined deletion/retention policy appears in the demo analysis.'],
        ['bad', 'Opt-out path', 'The user-control flow may require a manual request rather than a direct toggle.']
      ]
    },
    terms: {
      score: 62,
      title: 'Terms & conditions scan',
      desc: 'Several clauses may materially affect users and should be explained before acceptance.',
      signals: [
        ['bad', 'Arbitration', 'The demo flags a potentially restrictive dispute-resolution clause.'],
        ['warn', 'Auto-renewal', 'Subscription renewal language deserves explicit attention.'],
        ['good', 'Content ownership', 'The demo indicates comparatively clear user content rights.']
      ]
    },
    platform: {
      score: 84,
      title: 'Platform policy evaluation',
      desc: 'The demo shows generally clear controls with one notable tracking-related concern.',
      signals: [
        ['good', 'Security', 'Strong security language is surfaced in the simulated result.'],
        ['warn', 'Location access', 'Precise background location may deserve user scrutiny.'],
        ['good', 'User controls', 'Account-level controls are represented as relatively clear.']
      ]
    }
  };

  const buildTrustResult = (type) => {
    const data = trustData[type] || trustData.privacy;
    trustLoading?.classList.add('active');
    trustResults?.classList.remove('active');
    resultCircle?.setAttribute('stroke-dasharray', `0 ${circumference}`);
    resultScore && (resultScore.textContent = '0');

    window.setTimeout(() => {
      trustLoading?.classList.remove('active');
      trustResults?.classList.add('active');
      if (resultTitle) resultTitle.textContent = data.title;
      if (resultDesc) resultDesc.textContent = data.desc;
      if (resultSignals) {
        resultSignals.innerHTML = data.signals.map(([kind, title, desc]) => `
          <div class="signal-card ${kind}">
            <div class="signal-icon">${kind === 'good' ? '✓' : kind === 'warn' ? '!' : '×'}</div>
            <div><h5>${title}</h5><p>${desc}</p></div>
          </div>`).join('');
      }
      const color = data.score >= 75 ? '#65e6c1' : data.score >= 55 ? '#ffb36b' : '#ff6d83';
      if (resultCircle) {
        resultCircle.style.stroke = color;
        requestAnimationFrame(() => resultCircle.setAttribute('stroke-dasharray', `${(data.score / 100) * circumference} ${circumference}`));
      }
      let current = 0;
      const timer = setInterval(() => {
        current += 2;
        if (current >= data.score) { current = data.score; clearInterval(timer); }
        if (resultScore) resultScore.textContent = String(current);
      }, 22);
    }, 850);
  };

  $$('.analyze-btn').forEach((btn) => btn.addEventListener('click', () => buildTrustResult(btn.dataset.type)));
  $('.hint[data-fill="privacy"]')?.addEventListener('click', () => {
    const input = $('#policyInput');
    if (input) input.value = 'https://example.com/privacy-policy';
  });

  /* ---------------------------------------------------------
     AI DETECTION TABS + DEMO
  --------------------------------------------------------- */
  const detectTabs = $$('.detect-tab');
  const detectPanels = $$('.detect-panel');
  detectTabs.forEach((tab) => tab.addEventListener('click', () => {
    const mode = tab.dataset.mode;
    detectTabs.forEach((x) => x.classList.toggle('active', x === tab));
    detectPanels.forEach((panel) => panel.classList.toggle('active', panel.dataset.panel === mode));
  }));

  const detectionResult = $('#detectResult');
  const detectMeter = $('#detectMeter');
  const detectScore = $('#detectScore');
  const detectConfidence = $('#detectConfidence');
  const detectTitle = $('#detectTitle');
  const detectDesc = $('#detectDesc');
  const detectionData = {
    text: [73, 'Moderate confidence', 'AI-generation signal detected', 'The prototype detected a pattern worth reviewing. Production results should come from a validated detection model and present uncertainty clearly.'],
    image: [81, 'Moderate-high confidence', 'Synthetic-media signal detected', 'The visual interface is ready for metadata, provenance and model-based image analysis in production.'],
    video: [68, 'Moderate confidence', 'Mixed provenance signal', 'Production analysis could combine frame-level evidence, audio analysis, metadata and provenance signals.']
  };
  $$('.detection-btn').forEach((btn) => btn.addEventListener('click', () => {
    const type = btn.dataset.type;
    const [score, confidence, title, desc] = detectionData[type] || detectionData.text;
    btn.disabled = true;
    const old = btn.innerHTML;
    btn.innerHTML = 'Analyzing <span>…</span>';
    if (detectionResult) detectionResult.style.opacity = '.45';
    window.setTimeout(() => {
      btn.disabled = false;
      btn.innerHTML = old;
      if (detectionResult) detectionResult.style.opacity = '1';
      if (detectMeter) detectMeter.style.width = `${score}%`;
      if (detectScore) detectScore.textContent = `${score}%`;
      if (detectConfidence) detectConfidence.textContent = confidence;
      if (detectTitle) detectTitle.textContent = title;
      if (detectDesc) detectDesc.textContent = desc;
    }, 900);
  }));

  $$('input[type="file"]').forEach((input) => input.addEventListener('change', () => {
    const file = input.files?.[0];
    if (!file) return;
    const zone = input.closest('.upload-zone');
    const label = zone?.querySelector('b');
    if (label) label.textContent = file.name;
  }));

  /* ---------------------------------------------------------
     NEWS FILTER + SEARCH + SORT
  --------------------------------------------------------- */
  const newsCards = $$('.news-card');
  const filters = $$('.filter-pill');
  let activeFilter = 'all';

  const filterNews = () => {
    const query = ($('#newsSearch')?.value || '').trim().toLowerCase();
    newsCards.forEach((card) => {
      const matchesCategory = activeFilter === 'all' || card.dataset.category === activeFilter;
      const matchesQuery = !query || card.textContent.toLowerCase().includes(query);
      card.classList.toggle('hidden', !(matchesCategory && matchesQuery));
    });
  };
  filters.forEach((filter) => filter.addEventListener('click', () => {
    activeFilter = filter.dataset.filter;
    filters.forEach((x) => x.classList.toggle('active', x === filter));
    filterNews();
  }));
  $('#newsSearch')?.addEventListener('input', filterNews);
  $('#newsSort')?.addEventListener('change', (e) => {
    const container = $('#newsGrid');
    if (!container) return;
    const cards = [...container.children];
    cards.sort((a, b) => {
      const key = e.target.value === 'impact' ? 'impact' : 'date';
      return Number(b.dataset[key] || 0) - Number(a.dataset[key] || 0);
    });
    cards.forEach((card) => container.appendChild(card));
  });

  /* ---------------------------------------------------------
     AI ASSISTANT
  --------------------------------------------------------- */
  const aiToggle = $('#aiToggle');
  const chatWindow = $('#chatWindow');
  const chatClose = $('#chatClose');
  const chatForm = $('#chatForm');
  const chatInput = $('#chatInput');
  const chatMessages = $('#chatMessages');
  const chatTyping = $('#chatTyping');

  const addMessage = (text, sender) => {
    if (!chatMessages) return;
    const msg = document.createElement('div');
    msg.className = `msg ${sender}`;
    msg.textContent = text;
    chatMessages.appendChild(msg);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  };
  const assistantReply = (question) => {
    const q = question.toLowerCase();
    if (q.includes('policy') || q.includes('privacy') || q.includes('scan')) return 'The Trust Intelligence prototype is designed to surface privacy, sharing, retention, consent and user-control signals. The production version would connect this interface to a real analysis API.';
    if (q.includes('signal') || q.includes('trend')) return 'Signals tracks emerging movement across AI, privacy, cybersecurity, regulation and technology. The current entries are prototype data and can later be replaced by a live research/news feed.';
    if (q.includes('work') || q.includes('futurex')) return 'FutureX is a research and prototype studio focused on emerging technology, practical experiments and responsible digital experiences.';
    if (q.includes('ai') || q.includes('detect')) return 'The AI Detection experience is a frontend prototype for text, image and video provenance analysis. A production implementation would connect validated models or specialist services.';
    if (q.includes('terms') || q.includes('condition')) return 'The Terms scanner is intended to surface obligations, renewal rules, liability, arbitration, ownership and other clauses that users may want explained before accepting.';
    return 'That is a useful question. FutureX is designed to make complex AI, privacy and technology signals easier to understand and act on. Tell me what area you want to explore.';
  };
  const openChat = () => { chatWindow?.classList.add('open'); aiToggle?.setAttribute('aria-expanded','true'); chatInput?.focus(); };
  const closeChat = () => { chatWindow?.classList.remove('open'); aiToggle?.setAttribute('aria-expanded','false'); };
  aiToggle?.addEventListener('click', () => chatWindow?.classList.contains('open') ? closeChat() : openChat());
  chatClose?.addEventListener('click', closeChat);
  chatForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = chatInput?.value.trim();
    if (!text) return;
    addMessage(text, 'user');
    chatInput.value = '';
    chatTyping?.classList.add('active');
    window.setTimeout(() => {
      chatTyping?.classList.remove('active');
      addMessage(assistantReply(text), 'bot');
    }, 650);
  });
  $$('.chat-suggest').forEach((button) => button.addEventListener('click', () => {
    const text = button.dataset.suggestion || button.textContent.trim();
    if (chatInput) chatInput.value = text;
    if (!chatWindow?.classList.contains('open')) openChat();
    chatForm?.requestSubmit();
  }));

  /* ---------------------------------------------------------
     KEYBOARD + RESIZE
  --------------------------------------------------------- */
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeChat(); mobileMenu?.classList.remove('open'); menuToggle?.classList.remove('open'); } });
  window.addEventListener('resize', updateProgress);

  /* ---------------------------------------------------------
     INITIAL STATE
  --------------------------------------------------------- */
  updateProgress();
})();

  /* Close floating assistant when clicking outside it. */
  document.addEventListener('pointerdown', (event) => {
    if (!chatWindow?.classList.contains('open')) return;
    if (chatWindow.contains(event.target) || aiToggle?.contains(event.target)) return;
    setChat(false);
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      mobileMenu?.classList.remove('open');
      menuToggle?.classList.remove('open');
      menuToggle?.setAttribute('aria-expanded', 'false');
      setChat(false);
    }
  });
